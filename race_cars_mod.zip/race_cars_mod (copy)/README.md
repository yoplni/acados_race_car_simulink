This folder contains the code ported from Python to Matlab by Thomas Jespersen.
The original Python code has been used for the simulations and experiments associated with the publication:
*NMPC for Racing Using a Singularity-Free Path-Parametric Model with Obstacle Avoidance - Daniel Kloeser, Tobias Schoels, Tommaso Sartor, Andrea Zanelli, Gianluca Frison, Moritz Diehl. Proceedings of the 21th IFAC World Congress, Berlin, Germany - July 2020*.
A video of the experiments can be found on youtube: https://www.youtube.com/watch?v=1JDBQXVrZbo.
